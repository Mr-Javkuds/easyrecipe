package com.example.simple_recipe

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
