
class Recipe {
  String title;
  String gambar;
  String rating;
  String describe;
  String matrial;
  String step;

  Recipe({
    required this.gambar,
    required this.rating,
    required this.describe,
    required this.title,
    required this.matrial,
    required this.step,
  });
}

List<Recipe> recipeList = [
  Recipe(
      title: 'Batagor\n',
      gambar: "lib/img/batagor.jpg",
      rating: "Rating of 5/5",
      describe:
          "This is a very popular street food found around the Sunda region of Western Java.Batagor is an acronym for Bakso Tahu Goreng (Fried Tofu Balls) though it's not really a ball, but more of a triangle shape.The tofu is stuffed with a mixture of savory ground meat, steamed,and then coated with batter and fried;"
          "it is served with a spicy sweet chile-peanut sauce.",
      matrial: 'Ingredient:\n'
          '\n- 4 (8 ounce) containers tofu\n'
          '\n- ½ cup prawns - peeled, deveined, and minced\n'
          '\n- 1 egg, lightly beaten\n'
          '\n- 1 green onion, chopped\n'
          '\n- 2 teaspoons cornstarch\n'
          '\n- 1 teaspoons sesame oil\n'
          '\n- salt and ground white pepper to taste\n'
          '\n- 6 tablespoons all-purpose flour\n'
          '\nSauce:\n'
          '\n- ⅓ cup water\n'
          '\n- ¼ cup coarsely chopped dry roasted peanuts\n'
          '\n- 1 fresh red chile pepper, finely chopped\n'
          '\n- 2 cloves garlic, minced\n'
          '\n- 2 teaspoons white vinegar\n'
          '\n- 1 teaspoon white sugar\n'
          '\n- 1 teaspoon salt\n'
          '\n- oil for frying',
      step: '\nInstructions\n'
          '\n- Slice each tofu square diagonally to make 8 triangles. Make a cut into the base of each tofu triangle and scoop out enough of tofu to create a pocket.\n'
          '\n- Combine scooped-out tofu pieces, prawns, egg, ground chicken, green onion, cornstarch, sesame oil, salt, and pepper in a bowl for the filling. Carefully stuff filling back into the tofu triangles; the filling will bulge out.\n'
          '\n- Meanwhile, make the batter. Mix egg and flour in a bowl. Whisk in enough water to give batter a medium-thin consistency.\n'
          '\n- Combine water, peanuts, red chile pepper, garlic, vinegar, salt, and sugar in a bowl. Stir until salt and sugar have dissolved and set sauce aside.\n'
          '\n-Remove cooked tofu triangles from the steamer.\n'
          '\n-Heat oil in a wok until hot. Dip triangles into the batter and slowly lower into the hot oil. Fry in batches until golden brown and the batter is cooked through, about 5 minutes. Drain on paper towels. Serve hot with the peanut sauce.\n\n'),
  Recipe(
      title: 'Balsamic-Glazed Chicken Wings\n',
      gambar: "lib/img/chiken.jpg",
      rating: "Rating of 4.5/5",
      describe:
          "Put a big stack of napkins on the table because once you start eating these crispy, sticky, sweet glazed chicken wings, you won't want to stop. This can be an appetizer for four or main course for two",
      matrial: 'Ingredient:\n'
          '\n-  cooking spray \n'
          '\n- 3 tablespoons baking powder\n'
          '\n- 1½ teaspoons salt \n'
          '\n- 1½ teaspoons freshly ground black pepper\n'
          '\n- 1 teaspoon paprika\n'
          '\n- 2 pounds chicken wings, split and tips discarded\n'

          '\nGlaze:\n'
          '\n- ⅓  cup water\n'
          '\n- ⅓ cup balsamic vinegar \n'
          '\n- 2 tablespoons soy sauce\n'
          '\n- 2 tablespoons honey\n'
          '\n- 2 tablespoons chili sauce\n'
          '\n- 2 cloves garlic, minced\n'
          '\n- 1 teaspoon water\n'
          '\n- ¼ teaspoon cornstarch\n'

          '\nGarnish:\n'
          '\n1 green onion, thinly sliced \n'
          '\n¼ teaspoon toasted sesame seeds\n',

      step:
          '\nInstructions\n'
          '\n- Preheat an air fryer to 380 degrees F (190 degrees C). Coat the fryer basket with cooking spray.\n'
          '\n- Whisk baking powder, salt, pepper, and paprika together in a small bowl. Place baking powder mixture in a bag, add some of the chicken wings, and shake the bag to coat. Remove wings from the bag, shaking off excess powder, and repeat until all wings are coated with baking powder mixture.\n'
          '\n- Lightly spray the wings with cooking spray, place in the prepared air fryer basket, and cook for 20 minutes, shaking and flipping the wings halfway through. Increase the temperature to 400 degrees F (200 degrees C) and cook until crispy, about 5 minutes more. Depending on the size of your air fryer, you may have to cook the wings in batches.\n'
          '\n- Meanwhile, combine 1/3 cup water, balsamic vinegar, soy sauce, honey, chili sauce, and garlic in a saucepan over medium heat. Bring to a low boil and cook until sauce has reduced, about 15 minutes. Whisk together 1 teaspoon water and cornstarch in a small bowl and pour into the sauce; stir until sauce has thickened.\n'
          '\n- Place crispy wings into a large bowl, drizzle with sauce, and toss until well coated. Garnish with sliced green onion and sesame seeds, and serve immediately.\n'),
  Recipe(
      title: '\nMie Goreng\n',
      gambar: "lib/img/mie.jpg",
      rating: "Rating of 5/5",
      describe:
          "This tasty noodle dish is the same one my mom used to make for me when I was growing up. It's definitely comfort food. You can alter it with adding your favorite meats and veggies. \n",
      matrial: 'Ingredient:\n'
          '\n- 3 (3 ounce) packages ramen noodles \n'
          '\n- 1 pound skinless, boneless chicken breast halves, cut into strips \n'
          '\n- 1 teaspoon olive oil\n'
          '\n- 1 teaspoon garlic salt\n'
          '\n- 1 pinch ground black pepper, or to taste\n'
          '\n- 1 tablespoon vegetable oil \n'
          '\n- ½ cup chopped shallots\n'
          '\n- 5 cloves garlic, chopped\n'
          '\n- 1 cup shredded cabbage\n'
          '\n- 1 cup shredded carrots\n'
          '\n- 1 cup broccoli florets\n'
          '\n- 1 cup sliced fresh mushrooms \n'
          '\n- ¼ cup soy sauce \n'
          '\n- ¼ cup sweet soy sauce \n'
          '\n- 1 teaspoon salt\n'
          '\n- ¼ cup oyster sauce\n'
          '\n- salt and pepper to taste',
      step: '\nInstructions\n'
          '\n- Bring a pan of water to a boil, and cook the ramen until tender, about 3 minutes. Plunge the noodles into cold water to stop the cooking, drain in a colander set in the sink, and drizzle the noodles with 1 tablespoon of vegetable oil. Set aside.\n'
          '\n- Place the chicken strips in a bowl, and toss with olive oil, garlic salt, and black pepper. Heat 1 tablespoon of oil in a wok over high heat, and cook and stir the chicken until it is no longer pink, about 5 minutes. Stir in the shallots and garlic, and cook and stir until they start to turn brown. Add the cabbage, carrots, broccoli, and mushrooms, and cook and stir until the vegetables are tender, about 5 minutes.\n'
          '\n- Stir in the ramen noodles, soy sauce, sweet soy sauce, and oyster sauce, mixing the noodles and sauces into the vegetables and chicken. Bring the mixture to a simmer, sprinkle with salt and pepper, and serve hot.\n'),

  Recipe(
      title: 'Batagor\n',
      gambar: "lib/img/batagor.jpg",
      rating: "Rating of 5/5",
      describe:
      "This is a very popular street food found around the Sunda region of Western Java.Batagor is an acronym for Bakso Tahu Goreng (Fried Tofu Balls) though it's not really a ball, but more of a triangle shape.The tofu is stuffed with a mixture of savory ground meat, steamed,and then coated with batter and fried;"
          "it is served with a spicy sweet chile-peanut sauce.",
      matrial: 'Ingredient:\n'
          '\n- 4 (8 ounce) containers tofu\n'
          '\n- ½ cup prawns - peeled, deveined, and minced\n'
          '\n- 1 egg, lightly beaten\n'
          '\n- 1 green onion, chopped\n'
          '\n- 2 teaspoons cornstarch\n'
          '\n- 1 teaspoons sesame oil\n'
          '\n- salt and ground white pepper to taste\n'
          '\n- 6 tablespoons all-purpose flour\n'
          '\nSauce:\n'
          '\n- ⅓ cup water\n'
          '\n- ¼ cup coarsely chopped dry roasted peanuts\n'
          '\n- 1 fresh red chile pepper, finely chopped\n'
          '\n- 2 cloves garlic, minced\n'
          '\n- 2 teaspoons white vinegar\n'
          '\n- 1 teaspoon white sugar\n'
          '\n- 1 teaspoon salt\n'
          '\n- oil for frying',
      step: '\nInstructions\n'
          '\n- Slice each tofu square diagonally to make 8 triangles. Make a cut into the base of each tofu triangle and scoop out enough of tofu to create a pocket.\n'
          '\n- Combine scooped-out tofu pieces, prawns, egg, ground chicken, green onion, cornstarch, sesame oil, salt, and pepper in a bowl for the filling. Carefully stuff filling back into the tofu triangles; the filling will bulge out.\n'
          '\n- Meanwhile, make the batter. Mix egg and flour in a bowl. Whisk in enough water to give batter a medium-thin consistency.\n'
          '\n- Combine water, peanuts, red chile pepper, garlic, vinegar, salt, and sugar in a bowl. Stir until salt and sugar have dissolved and set sauce aside.\n'
          '\n-Remove cooked tofu triangles from the steamer.\n'
          '\n-Heat oil in a wok until hot. Dip triangles into the batter and slowly lower into the hot oil. Fry in batches until golden brown and the batter is cooked through, about 5 minutes. Drain on paper towels. Serve hot with the peanut sauce.\n\n'),
  Recipe(
      title: 'Balsamic-Glazed Chicken Wings\n',
      gambar: "lib/img/chiken.jpg",
      rating: "Rating of 4.5/5",
      describe:
      "Put a big stack of napkins on the table because once you start eating these crispy, sticky, sweet glazed chicken wings, you won't want to stop. This can be an appetizer for four or main course for two",
      matrial: 'Ingredient:\n'
          '\n-  cooking spray \n'
          '\n- 3 tablespoons baking powder\n'
          '\n- 1½ teaspoons salt \n'
          '\n- 1½ teaspoons freshly ground black pepper\n'
          '\n- 1 teaspoon paprika\n'
          '\n- 2 pounds chicken wings, split and tips discarded\n'

          '\nGlaze:\n'
          '\n- ⅓  cup water\n'
          '\n- ⅓ cup balsamic vinegar \n'
          '\n- 2 tablespoons soy sauce\n'
          '\n- 2 tablespoons honey\n'
          '\n- 2 tablespoons chili sauce\n'
          '\n- 2 cloves garlic, minced\n'
          '\n- 1 teaspoon water\n'
          '\n- ¼ teaspoon cornstarch\n'

          '\nGarnish:\n'
          '\n1 green onion, thinly sliced \n'
          '\n¼ teaspoon toasted sesame seeds\n',

      step:
      '\nInstructions\n'
          '\n- Preheat an air fryer to 380 degrees F (190 degrees C). Coat the fryer basket with cooking spray.\n'
          '\n- Whisk baking powder, salt, pepper, and paprika together in a small bowl. Place baking powder mixture in a bag, add some of the chicken wings, and shake the bag to coat. Remove wings from the bag, shaking off excess powder, and repeat until all wings are coated with baking powder mixture.\n'
          '\n- Lightly spray the wings with cooking spray, place in the prepared air fryer basket, and cook for 20 minutes, shaking and flipping the wings halfway through. Increase the temperature to 400 degrees F (200 degrees C) and cook until crispy, about 5 minutes more. Depending on the size of your air fryer, you may have to cook the wings in batches.\n'
          '\n- Meanwhile, combine 1/3 cup water, balsamic vinegar, soy sauce, honey, chili sauce, and garlic in a saucepan over medium heat. Bring to a low boil and cook until sauce has reduced, about 15 minutes. Whisk together 1 teaspoon water and cornstarch in a small bowl and pour into the sauce; stir until sauce has thickened.\n'
          '\n- Place crispy wings into a large bowl, drizzle with sauce, and toss until well coated. Garnish with sliced green onion and sesame seeds, and serve immediately.\n'),
  Recipe(
      title: '\nMie Goreng\n',
      gambar: "lib/img/mie.jpg",
      rating: "Rating of 5/5",
      describe:
      "This tasty noodle dish is the same one my mom used to make for me when I was growing up. It's definitely comfort food. You can alter it with adding your favorite meats and veggies. \n",
      matrial: 'Ingredient:\n'
          '\n- 3 (3 ounce) packages ramen noodles \n'
          '\n- 1 pound skinless, boneless chicken breast halves, cut into strips \n'
          '\n- 1 teaspoon olive oil\n'
          '\n- 1 teaspoon garlic salt\n'
          '\n- 1 pinch ground black pepper, or to taste\n'
          '\n- 1 tablespoon vegetable oil \n'
          '\n- ½ cup chopped shallots\n'
          '\n- 5 cloves garlic, chopped\n'
          '\n- 1 cup shredded cabbage\n'
          '\n- 1 cup shredded carrots\n'
          '\n- 1 cup broccoli florets\n'
          '\n- 1 cup sliced fresh mushrooms \n'
          '\n- ¼ cup soy sauce \n'
          '\n- ¼ cup sweet soy sauce \n'
          '\n- 1 teaspoon salt\n'
          '\n- ¼ cup oyster sauce\n'
          '\n- salt and pepper to taste',
      step: '\nInstructions\n'
          '\n- Bring a pan of water to a boil, and cook the ramen until tender, about 3 minutes. Plunge the noodles into cold water to stop the cooking, drain in a colander set in the sink, and drizzle the noodles with 1 tablespoon of vegetable oil. Set aside.\n'
          '\n- Place the chicken strips in a bowl, and toss with olive oil, garlic salt, and black pepper. Heat 1 tablespoon of oil in a wok over high heat, and cook and stir the chicken until it is no longer pink, about 5 minutes. Stir in the shallots and garlic, and cook and stir until they start to turn brown. Add the cabbage, carrots, broccoli, and mushrooms, and cook and stir until the vegetables are tender, about 5 minutes.\n'
          '\n- Stir in the ramen noodles, soy sauce, sweet soy sauce, and oyster sauce, mixing the noodles and sauces into the vegetables and chicken. Bring the mixture to a simmer, sprinkle with salt and pepper, and serve hot.\n'),

  Recipe(
      title: 'Batagor\n',
      gambar: "lib/img/batagor.jpg",
      rating: "Rating of 5/5",
      describe:
      "This is a very popular street food found around the Sunda region of Western Java.Batagor is an acronym for Bakso Tahu Goreng (Fried Tofu Balls) though it's not really a ball, but more of a triangle shape.The tofu is stuffed with a mixture of savory ground meat, steamed,and then coated with batter and fried;"
          "it is served with a spicy sweet chile-peanut sauce.",
      matrial: 'Ingredient:\n'
          '\n- 4 (8 ounce) containers tofu\n'
          '\n- ½ cup prawns - peeled, deveined, and minced\n'
          '\n- 1 egg, lightly beaten\n'
          '\n- 1 green onion, chopped\n'
          '\n- 2 teaspoons cornstarch\n'
          '\n- 1 teaspoons sesame oil\n'
          '\n- salt and ground white pepper to taste\n'
          '\n- 6 tablespoons all-purpose flour\n'
          '\nSauce:\n'
          '\n- ⅓ cup water\n'
          '\n- ¼ cup coarsely chopped dry roasted peanuts\n'
          '\n- 1 fresh red chile pepper, finely chopped\n'
          '\n- 2 cloves garlic, minced\n'
          '\n- 2 teaspoons white vinegar\n'
          '\n- 1 teaspoon white sugar\n'
          '\n- 1 teaspoon salt\n'
          '\n- oil for frying',
      step: '\nInstructions\n'
          '\n- Slice each tofu square diagonally to make 8 triangles. Make a cut into the base of each tofu triangle and scoop out enough of tofu to create a pocket.\n'
          '\n- Combine scooped-out tofu pieces, prawns, egg, ground chicken, green onion, cornstarch, sesame oil, salt, and pepper in a bowl for the filling. Carefully stuff filling back into the tofu triangles; the filling will bulge out.\n'
          '\n- Meanwhile, make the batter. Mix egg and flour in a bowl. Whisk in enough water to give batter a medium-thin consistency.\n'
          '\n- Combine water, peanuts, red chile pepper, garlic, vinegar, salt, and sugar in a bowl. Stir until salt and sugar have dissolved and set sauce aside.\n'
          '\n-Remove cooked tofu triangles from the steamer.\n'
          '\n-Heat oil in a wok until hot. Dip triangles into the batter and slowly lower into the hot oil. Fry in batches until golden brown and the batter is cooked through, about 5 minutes. Drain on paper towels. Serve hot with the peanut sauce.\n\n'),
  Recipe(
      title: 'Balsamic-Glazed Chicken Wings\n',
      gambar: "lib/img/chiken.jpg",
      rating: "Rating of 4.5/5",
      describe:
      "Put a big stack of napkins on the table because once you start eating these crispy, sticky, sweet glazed chicken wings, you won't want to stop. This can be an appetizer for four or main course for two",
      matrial: 'Ingredient:\n'
          '\n-  cooking spray \n'
          '\n- 3 tablespoons baking powder\n'
          '\n- 1½ teaspoons salt \n'
          '\n- 1½ teaspoons freshly ground black pepper\n'
          '\n- 1 teaspoon paprika\n'
          '\n- 2 pounds chicken wings, split and tips discarded\n'

          '\nGlaze:\n'
          '\n- ⅓  cup water\n'
          '\n- ⅓ cup balsamic vinegar \n'
          '\n- 2 tablespoons soy sauce\n'
          '\n- 2 tablespoons honey\n'
          '\n- 2 tablespoons chili sauce\n'
          '\n- 2 cloves garlic, minced\n'
          '\n- 1 teaspoon water\n'
          '\n- ¼ teaspoon cornstarch\n'

          '\nGarnish:\n'
          '\n1 green onion, thinly sliced \n'
          '\n¼ teaspoon toasted sesame seeds\n',

      step:
      '\nInstructions\n'
          '\n- Preheat an air fryer to 380 degrees F (190 degrees C). Coat the fryer basket with cooking spray.\n'
          '\n- Whisk baking powder, salt, pepper, and paprika together in a small bowl. Place baking powder mixture in a bag, add some of the chicken wings, and shake the bag to coat. Remove wings from the bag, shaking off excess powder, and repeat until all wings are coated with baking powder mixture.\n'
          '\n- Lightly spray the wings with cooking spray, place in the prepared air fryer basket, and cook for 20 minutes, shaking and flipping the wings halfway through. Increase the temperature to 400 degrees F (200 degrees C) and cook until crispy, about 5 minutes more. Depending on the size of your air fryer, you may have to cook the wings in batches.\n'
          '\n- Meanwhile, combine 1/3 cup water, balsamic vinegar, soy sauce, honey, chili sauce, and garlic in a saucepan over medium heat. Bring to a low boil and cook until sauce has reduced, about 15 minutes. Whisk together 1 teaspoon water and cornstarch in a small bowl and pour into the sauce; stir until sauce has thickened.\n'
          '\n- Place crispy wings into a large bowl, drizzle with sauce, and toss until well coated. Garnish with sliced green onion and sesame seeds, and serve immediately.\n'),
  Recipe(
      title: '\nMie Goreng\n',
      gambar: "lib/img/mie.jpg",
      rating: "Rating of 5/5",
      describe:
      "This tasty noodle dish is the same one my mom used to make for me when I was growing up. It's definitely comfort food. You can alter it with adding your favorite meats and veggies. \n",
      matrial: 'Ingredient:\n'
          '\n- 3 (3 ounce) packages ramen noodles \n'
          '\n- 1 pound skinless, boneless chicken breast halves, cut into strips \n'
          '\n- 1 teaspoon olive oil\n'
          '\n- 1 teaspoon garlic salt\n'
          '\n- 1 pinch ground black pepper, or to taste\n'
          '\n- 1 tablespoon vegetable oil \n'
          '\n- ½ cup chopped shallots\n'
          '\n- 5 cloves garlic, chopped\n'
          '\n- 1 cup shredded cabbage\n'
          '\n- 1 cup shredded carrots\n'
          '\n- 1 cup broccoli florets\n'
          '\n- 1 cup sliced fresh mushrooms \n'
          '\n- ¼ cup soy sauce \n'
          '\n- ¼ cup sweet soy sauce \n'
          '\n- 1 teaspoon salt\n'
          '\n- ¼ cup oyster sauce\n'
          '\n- salt and pepper to taste',
      step: '\nInstructions\n'
          '\n- Bring a pan of water to a boil, and cook the ramen until tender, about 3 minutes. Plunge the noodles into cold water to stop the cooking, drain in a colander set in the sink, and drizzle the noodles with 1 tablespoon of vegetable oil. Set aside.\n'
          '\n- Place the chicken strips in a bowl, and toss with olive oil, garlic salt, and black pepper. Heat 1 tablespoon of oil in a wok over high heat, and cook and stir the chicken until it is no longer pink, about 5 minutes. Stir in the shallots and garlic, and cook and stir until they start to turn brown. Add the cabbage, carrots, broccoli, and mushrooms, and cook and stir until the vegetables are tender, about 5 minutes.\n'
          '\n- Stir in the ramen noodles, soy sauce, sweet soy sauce, and oyster sauce, mixing the noodles and sauces into the vegetables and chicken. Bring the mixture to a simmer, sprinkle with salt and pepper, and serve hot.\n'),

  Recipe(
      title: 'Batagor\n',
      gambar: "lib/img/batagor.jpg",
      rating: "Rating of 5/5",
      describe:
      "This is a very popular street food found around the Sunda region of Western Java.Batagor is an acronym for Bakso Tahu Goreng (Fried Tofu Balls) though it's not really a ball, but more of a triangle shape.The tofu is stuffed with a mixture of savory ground meat, steamed,and then coated with batter and fried;"
          "it is served with a spicy sweet chile-peanut sauce.",
      matrial: 'Ingredient:\n'
          '\n- 4 (8 ounce) containers tofu\n'
          '\n- ½ cup prawns - peeled, deveined, and minced\n'
          '\n- 1 egg, lightly beaten\n'
          '\n- 1 green onion, chopped\n'
          '\n- 2 teaspoons cornstarch\n'
          '\n- 1 teaspoons sesame oil\n'
          '\n- salt and ground white pepper to taste\n'
          '\n- 6 tablespoons all-purpose flour\n'
          '\nSauce:\n'
          '\n- ⅓ cup water\n'
          '\n- ¼ cup coarsely chopped dry roasted peanuts\n'
          '\n- 1 fresh red chile pepper, finely chopped\n'
          '\n- 2 cloves garlic, minced\n'
          '\n- 2 teaspoons white vinegar\n'
          '\n- 1 teaspoon white sugar\n'
          '\n- 1 teaspoon salt\n'
          '\n- oil for frying',
      step: '\nInstructions\n'
          '\n- Slice each tofu square diagonally to make 8 triangles. Make a cut into the base of each tofu triangle and scoop out enough of tofu to create a pocket.\n'
          '\n- Combine scooped-out tofu pieces, prawns, egg, ground chicken, green onion, cornstarch, sesame oil, salt, and pepper in a bowl for the filling. Carefully stuff filling back into the tofu triangles; the filling will bulge out.\n'
          '\n- Meanwhile, make the batter. Mix egg and flour in a bowl. Whisk in enough water to give batter a medium-thin consistency.\n'
          '\n- Combine water, peanuts, red chile pepper, garlic, vinegar, salt, and sugar in a bowl. Stir until salt and sugar have dissolved and set sauce aside.\n'
          '\n-Remove cooked tofu triangles from the steamer.\n'
          '\n-Heat oil in a wok until hot. Dip triangles into the batter and slowly lower into the hot oil. Fry in batches until golden brown and the batter is cooked through, about 5 minutes. Drain on paper towels. Serve hot with the peanut sauce.\n\n'),
  Recipe(
      title: 'Balsamic-Glazed Chicken Wings\n',
      gambar: "lib/img/chiken.jpg",
      rating: "Rating of 4.5/5",
      describe:
      "Put a big stack of napkins on the table because once you start eating these crispy, sticky, sweet glazed chicken wings, you won't want to stop. This can be an appetizer for four or main course for two",
      matrial: 'Ingredient:\n'
          '\n-  cooking spray \n'
          '\n- 3 tablespoons baking powder\n'
          '\n- 1½ teaspoons salt \n'
          '\n- 1½ teaspoons freshly ground black pepper\n'
          '\n- 1 teaspoon paprika\n'
          '\n- 2 pounds chicken wings, split and tips discarded\n'

          '\nGlaze:\n'
          '\n- ⅓  cup water\n'
          '\n- ⅓ cup balsamic vinegar \n'
          '\n- 2 tablespoons soy sauce\n'
          '\n- 2 tablespoons honey\n'
          '\n- 2 tablespoons chili sauce\n'
          '\n- 2 cloves garlic, minced\n'
          '\n- 1 teaspoon water\n'
          '\n- ¼ teaspoon cornstarch\n'

          '\nGarnish:\n'
          '\n1 green onion, thinly sliced \n'
          '\n¼ teaspoon toasted sesame seeds\n',

      step:
      '\nInstructions\n'
          '\n- Preheat an air fryer to 380 degrees F (190 degrees C). Coat the fryer basket with cooking spray.\n'
          '\n- Whisk baking powder, salt, pepper, and paprika together in a small bowl. Place baking powder mixture in a bag, add some of the chicken wings, and shake the bag to coat. Remove wings from the bag, shaking off excess powder, and repeat until all wings are coated with baking powder mixture.\n'
          '\n- Lightly spray the wings with cooking spray, place in the prepared air fryer basket, and cook for 20 minutes, shaking and flipping the wings halfway through. Increase the temperature to 400 degrees F (200 degrees C) and cook until crispy, about 5 minutes more. Depending on the size of your air fryer, you may have to cook the wings in batches.\n'
          '\n- Meanwhile, combine 1/3 cup water, balsamic vinegar, soy sauce, honey, chili sauce, and garlic in a saucepan over medium heat. Bring to a low boil and cook until sauce has reduced, about 15 minutes. Whisk together 1 teaspoon water and cornstarch in a small bowl and pour into the sauce; stir until sauce has thickened.\n'
          '\n- Place crispy wings into a large bowl, drizzle with sauce, and toss until well coated. Garnish with sliced green onion and sesame seeds, and serve immediately.\n'),
  Recipe(
      title: '\nMie Goreng\n',
      gambar: "lib/img/mie.jpg",
      rating: "Rating of 5/5",
      describe:
      "This tasty noodle dish is the same one my mom used to make for me when I was growing up. It's definitely comfort food. You can alter it with adding your favorite meats and veggies. \n",
      matrial: 'Ingredient:\n'
          '\n- 3 (3 ounce) packages ramen noodles \n'
          '\n- 1 pound skinless, boneless chicken breast halves, cut into strips \n'
          '\n- 1 teaspoon olive oil\n'
          '\n- 1 teaspoon garlic salt\n'
          '\n- 1 pinch ground black pepper, or to taste\n'
          '\n- 1 tablespoon vegetable oil \n'
          '\n- ½ cup chopped shallots\n'
          '\n- 5 cloves garlic, chopped\n'
          '\n- 1 cup shredded cabbage\n'
          '\n- 1 cup shredded carrots\n'
          '\n- 1 cup broccoli florets\n'
          '\n- 1 cup sliced fresh mushrooms \n'
          '\n- ¼ cup soy sauce \n'
          '\n- ¼ cup sweet soy sauce \n'
          '\n- 1 teaspoon salt\n'
          '\n- ¼ cup oyster sauce\n'
          '\n- salt and pepper to taste',
      step: '\nInstructions\n'
          '\n- Bring a pan of water to a boil, and cook the ramen until tender, about 3 minutes. Plunge the noodles into cold water to stop the cooking, drain in a colander set in the sink, and drizzle the noodles with 1 tablespoon of vegetable oil. Set aside.\n'
          '\n- Place the chicken strips in a bowl, and toss with olive oil, garlic salt, and black pepper. Heat 1 tablespoon of oil in a wok over high heat, and cook and stir the chicken until it is no longer pink, about 5 minutes. Stir in the shallots and garlic, and cook and stir until they start to turn brown. Add the cabbage, carrots, broccoli, and mushrooms, and cook and stir until the vegetables are tender, about 5 minutes.\n'
          '\n- Stir in the ramen noodles, soy sauce, sweet soy sauce, and oyster sauce, mixing the noodles and sauces into the vegetables and chicken. Bring the mixture to a simmer, sprinkle with salt and pepper, and serve hot.\n'),

  Recipe(
      title: 'Batagor\n',
      gambar: "lib/img/batagor.jpg",
      rating: "Rating of 5/5",
      describe:
      "This is a very popular street food found around the Sunda region of Western Java.Batagor is an acronym for Bakso Tahu Goreng (Fried Tofu Balls) though it's not really a ball, but more of a triangle shape.The tofu is stuffed with a mixture of savory ground meat, steamed,and then coated with batter and fried;"
          "it is served with a spicy sweet chile-peanut sauce.",
      matrial: 'Ingredient:\n'
          '\n- 4 (8 ounce) containers tofu\n'
          '\n- ½ cup prawns - peeled, deveined, and minced\n'
          '\n- 1 egg, lightly beaten\n'
          '\n- 1 green onion, chopped\n'
          '\n- 2 teaspoons cornstarch\n'
          '\n- 1 teaspoons sesame oil\n'
          '\n- salt and ground white pepper to taste\n'
          '\n- 6 tablespoons all-purpose flour\n'
          '\nSauce:\n'
          '\n- ⅓ cup water\n'
          '\n- ¼ cup coarsely chopped dry roasted peanuts\n'
          '\n- 1 fresh red chile pepper, finely chopped\n'
          '\n- 2 cloves garlic, minced\n'
          '\n- 2 teaspoons white vinegar\n'
          '\n- 1 teaspoon white sugar\n'
          '\n- 1 teaspoon salt\n'
          '\n- oil for frying',
      step: '\nInstructions\n'
          '\n- Slice each tofu square diagonally to make 8 triangles. Make a cut into the base of each tofu triangle and scoop out enough of tofu to create a pocket.\n'
          '\n- Combine scooped-out tofu pieces, prawns, egg, ground chicken, green onion, cornstarch, sesame oil, salt, and pepper in a bowl for the filling. Carefully stuff filling back into the tofu triangles; the filling will bulge out.\n'
          '\n- Meanwhile, make the batter. Mix egg and flour in a bowl. Whisk in enough water to give batter a medium-thin consistency.\n'
          '\n- Combine water, peanuts, red chile pepper, garlic, vinegar, salt, and sugar in a bowl. Stir until salt and sugar have dissolved and set sauce aside.\n'
          '\n-Remove cooked tofu triangles from the steamer.\n'
          '\n-Heat oil in a wok until hot. Dip triangles into the batter and slowly lower into the hot oil. Fry in batches until golden brown and the batter is cooked through, about 5 minutes. Drain on paper towels. Serve hot with the peanut sauce.\n\n'),
  Recipe(
      title: 'Balsamic-Glazed Chicken Wings\n',
      gambar: "lib/img/chiken.jpg",
      rating: "Rating of 4.5/5",
      describe:
      "Put a big stack of napkins on the table because once you start eating these crispy, sticky, sweet glazed chicken wings, you won't want to stop. This can be an appetizer for four or main course for two",
      matrial: 'Ingredient:\n'
          '\n-  cooking spray \n'
          '\n- 3 tablespoons baking powder\n'
          '\n- 1½ teaspoons salt \n'
          '\n- 1½ teaspoons freshly ground black pepper\n'
          '\n- 1 teaspoon paprika\n'
          '\n- 2 pounds chicken wings, split and tips discarded\n'

          '\nGlaze:\n'
          '\n- ⅓  cup water\n'
          '\n- ⅓ cup balsamic vinegar \n'
          '\n- 2 tablespoons soy sauce\n'
          '\n- 2 tablespoons honey\n'
          '\n- 2 tablespoons chili sauce\n'
          '\n- 2 cloves garlic, minced\n'
          '\n- 1 teaspoon water\n'
          '\n- ¼ teaspoon cornstarch\n'

          '\nGarnish:\n'
          '\n1 green onion, thinly sliced \n'
          '\n¼ teaspoon toasted sesame seeds\n',

      step:
      '\nInstructions\n'
          '\n- Preheat an air fryer to 380 degrees F (190 degrees C). Coat the fryer basket with cooking spray.\n'
          '\n- Whisk baking powder, salt, pepper, and paprika together in a small bowl. Place baking powder mixture in a bag, add some of the chicken wings, and shake the bag to coat. Remove wings from the bag, shaking off excess powder, and repeat until all wings are coated with baking powder mixture.\n'
          '\n- Lightly spray the wings with cooking spray, place in the prepared air fryer basket, and cook for 20 minutes, shaking and flipping the wings halfway through. Increase the temperature to 400 degrees F (200 degrees C) and cook until crispy, about 5 minutes more. Depending on the size of your air fryer, you may have to cook the wings in batches.\n'
          '\n- Meanwhile, combine 1/3 cup water, balsamic vinegar, soy sauce, honey, chili sauce, and garlic in a saucepan over medium heat. Bring to a low boil and cook until sauce has reduced, about 15 minutes. Whisk together 1 teaspoon water and cornstarch in a small bowl and pour into the sauce; stir until sauce has thickened.\n'
          '\n- Place crispy wings into a large bowl, drizzle with sauce, and toss until well coated. Garnish with sliced green onion and sesame seeds, and serve immediately.\n'),
  Recipe(
      title: '\nMie Goreng\n',
      gambar: "lib/img/mie.jpg",
      rating: "Rating of 5/5",
      describe:
      "This tasty noodle dish is the same one my mom used to make for me when I was growing up. It's definitely comfort food. You can alter it with adding your favorite meats and veggies. \n",
      matrial: 'Ingredient:\n'
          '\n- 3 (3 ounce) packages ramen noodles \n'
          '\n- 1 pound skinless, boneless chicken breast halves, cut into strips \n'
          '\n- 1 teaspoon olive oil\n'
          '\n- 1 teaspoon garlic salt\n'
          '\n- 1 pinch ground black pepper, or to taste\n'
          '\n- 1 tablespoon vegetable oil \n'
          '\n- ½ cup chopped shallots\n'
          '\n- 5 cloves garlic, chopped\n'
          '\n- 1 cup shredded cabbage\n'
          '\n- 1 cup shredded carrots\n'
          '\n- 1 cup broccoli florets\n'
          '\n- 1 cup sliced fresh mushrooms \n'
          '\n- ¼ cup soy sauce \n'
          '\n- ¼ cup sweet soy sauce \n'
          '\n- 1 teaspoon salt\n'
          '\n- ¼ cup oyster sauce\n'
          '\n- salt and pepper to taste',
      step: '\nInstructions\n'
          '\n- Bring a pan of water to a boil, and cook the ramen until tender, about 3 minutes. Plunge the noodles into cold water to stop the cooking, drain in a colander set in the sink, and drizzle the noodles with 1 tablespoon of vegetable oil. Set aside.\n'
          '\n- Place the chicken strips in a bowl, and toss with olive oil, garlic salt, and black pepper. Heat 1 tablespoon of oil in a wok over high heat, and cook and stir the chicken until it is no longer pink, about 5 minutes. Stir in the shallots and garlic, and cook and stir until they start to turn brown. Add the cabbage, carrots, broccoli, and mushrooms, and cook and stir until the vegetables are tender, about 5 minutes.\n'
          '\n- Stir in the ramen noodles, soy sauce, sweet soy sauce, and oyster sauce, mixing the noodles and sauces into the vegetables and chicken. Bring the mixture to a simmer, sprinkle with salt and pepper, and serve hot.\n'),

  Recipe(
      title: 'Batagor\n',
      gambar: "lib/img/batagor.jpg",
      rating: "Rating of 5/5",
      describe:
      "This is a very popular street food found around the Sunda region of Western Java.Batagor is an acronym for Bakso Tahu Goreng (Fried Tofu Balls) though it's not really a ball, but more of a triangle shape.The tofu is stuffed with a mixture of savory ground meat, steamed,and then coated with batter and fried;"
          "it is served with a spicy sweet chile-peanut sauce.",
      matrial: 'Ingredient:\n'
          '\n- 4 (8 ounce) containers tofu\n'
          '\n- ½ cup prawns - peeled, deveined, and minced\n'
          '\n- 1 egg, lightly beaten\n'
          '\n- 1 green onion, chopped\n'
          '\n- 2 teaspoons cornstarch\n'
          '\n- 1 teaspoons sesame oil\n'
          '\n- salt and ground white pepper to taste\n'
          '\n- 6 tablespoons all-purpose flour\n'
          '\nSauce:\n'
          '\n- ⅓ cup water\n'
          '\n- ¼ cup coarsely chopped dry roasted peanuts\n'
          '\n- 1 fresh red chile pepper, finely chopped\n'
          '\n- 2 cloves garlic, minced\n'
          '\n- 2 teaspoons white vinegar\n'
          '\n- 1 teaspoon white sugar\n'
          '\n- 1 teaspoon salt\n'
          '\n- oil for frying',
      step: '\nInstructions\n'
          '\n- Slice each tofu square diagonally to make 8 triangles. Make a cut into the base of each tofu triangle and scoop out enough of tofu to create a pocket.\n'
          '\n- Combine scooped-out tofu pieces, prawns, egg, ground chicken, green onion, cornstarch, sesame oil, salt, and pepper in a bowl for the filling. Carefully stuff filling back into the tofu triangles; the filling will bulge out.\n'
          '\n- Meanwhile, make the batter. Mix egg and flour in a bowl. Whisk in enough water to give batter a medium-thin consistency.\n'
          '\n- Combine water, peanuts, red chile pepper, garlic, vinegar, salt, and sugar in a bowl. Stir until salt and sugar have dissolved and set sauce aside.\n'
          '\n-Remove cooked tofu triangles from the steamer.\n'
          '\n-Heat oil in a wok until hot. Dip triangles into the batter and slowly lower into the hot oil. Fry in batches until golden brown and the batter is cooked through, about 5 minutes. Drain on paper towels. Serve hot with the peanut sauce.\n\n'),
  Recipe(
      title: 'Balsamic-Glazed Chicken Wings\n',
      gambar: "lib/img/chiken.jpg",
      rating: "Rating of 4.5/5",
      describe:
      "Put a big stack of napkins on the table because once you start eating these crispy, sticky, sweet glazed chicken wings, you won't want to stop. This can be an appetizer for four or main course for two",
      matrial: 'Ingredient:\n'
          '\n-  cooking spray \n'
          '\n- 3 tablespoons baking powder\n'
          '\n- 1½ teaspoons salt \n'
          '\n- 1½ teaspoons freshly ground black pepper\n'
          '\n- 1 teaspoon paprika\n'
          '\n- 2 pounds chicken wings, split and tips discarded\n'

          '\nGlaze:\n'
          '\n- ⅓  cup water\n'
          '\n- ⅓ cup balsamic vinegar \n'
          '\n- 2 tablespoons soy sauce\n'
          '\n- 2 tablespoons honey\n'
          '\n- 2 tablespoons chili sauce\n'
          '\n- 2 cloves garlic, minced\n'
          '\n- 1 teaspoon water\n'
          '\n- ¼ teaspoon cornstarch\n'

          '\nGarnish:\n'
          '\n1 green onion, thinly sliced \n'
          '\n¼ teaspoon toasted sesame seeds\n',

      step:
      '\nInstructions\n'
          '\n- Preheat an air fryer to 380 degrees F (190 degrees C). Coat the fryer basket with cooking spray.\n'
          '\n- Whisk baking powder, salt, pepper, and paprika together in a small bowl. Place baking powder mixture in a bag, add some of the chicken wings, and shake the bag to coat. Remove wings from the bag, shaking off excess powder, and repeat until all wings are coated with baking powder mixture.\n'
          '\n- Lightly spray the wings with cooking spray, place in the prepared air fryer basket, and cook for 20 minutes, shaking and flipping the wings halfway through. Increase the temperature to 400 degrees F (200 degrees C) and cook until crispy, about 5 minutes more. Depending on the size of your air fryer, you may have to cook the wings in batches.\n'
          '\n- Meanwhile, combine 1/3 cup water, balsamic vinegar, soy sauce, honey, chili sauce, and garlic in a saucepan over medium heat. Bring to a low boil and cook until sauce has reduced, about 15 minutes. Whisk together 1 teaspoon water and cornstarch in a small bowl and pour into the sauce; stir until sauce has thickened.\n'
          '\n- Place crispy wings into a large bowl, drizzle with sauce, and toss until well coated. Garnish with sliced green onion and sesame seeds, and serve immediately.\n'),
  Recipe(
      title: 'nnMie Goreng\n',
      gambar: "lib/img/mie.jpg",
      rating: "Rating of 5/5",
      describe:
      "This tasty noodle dish is the same one my mom used to make for me when I was growing up. It's definitely comfort food. You can alter it with adding your favorite meats and veggies. \n",
      matrial: 'Ingredient:\n'
          '\n- 3 (3 ounce) packages ramen noodles \n'
          '\n- 1 pound skinless, boneless chicken breast halves, cut into strips \n'
          '\n- 1 teaspoon olive oil\n'
          '\n- 1 teaspoon garlic salt\n'
          '\n- 1 pinch ground black pepper, or to taste\n'
          '\n- 1 tablespoon vegetable oil \n'
          '\n- ½ cup chopped shallots\n'
          '\n- 5 cloves garlic, chopped\n'
          '\n- 1 cup shredded cabbage\n'
          '\n- 1 cup shredded carrots\n'
          '\n- 1 cup broccoli florets\n'
          '\n- 1 cup sliced fresh mushrooms \n'
          '\n- ¼ cup soy sauce \n'
          '\n- ¼ cup sweet soy sauce \n'
          '\n- 1 teaspoon salt\n'
          '\n- ¼ cup oyster sauce\n'
          '\n- salt and pepper to taste',
      step: '\nInstructions\n'
          '\n- Bring a pan of water to a boil, and cook the ramen until tender, about 3 minutes. Plunge the noodles into cold water to stop the cooking, drain in a colander set in the sink, and drizzle the noodles with 1 tablespoon of vegetable oil. Set aside.\n'
          '\n- Place the chicken strips in a bowl, and toss with olive oil, garlic salt, and black pepper. Heat 1 tablespoon of oil in a wok over high heat, and cook and stir the chicken until it is no longer pink, about 5 minutes. Stir in the shallots and garlic, and cook and stir until they start to turn brown. Add the cabbage, carrots, broccoli, and mushrooms, and cook and stir until the vegetables are tender, about 5 minutes.\n'
          '\n- Stir in the ramen noodles, soy sauce, sweet soy sauce, and oyster sauce, mixing the noodles and sauces into the vegetables and chicken. Bring the mixture to a simmer, sprinkle with salt and pepper, and serve hot.\n'),

  Recipe(
      title: 'Batagor\n',
      gambar: "lib/img/batagor.jpg",
      rating: "Rating of 5/5",
      describe:
      "This is a very popular street food found around the Sunda region of Western Java.Batagor is an acronym for Bakso Tahu Goreng (Fried Tofu Balls) though it's not really a ball, but more of a triangle shape.The tofu is stuffed with a mixture of savory ground meat, steamed,and then coated with batter and fried;"
          "it is served with a spicy sweet chile-peanut sauce.",
      matrial: 'Ingredient:\n'
          '\n- 4 (8 ounce) containers tofu\n'
          '\n- ½ cup prawns - peeled, deveined, and minced\n'
          '\n- 1 egg, lightly beaten\n'
          '\n- 1 green onion, chopped\n'
          '\n- 2 teaspoons cornstarch\n'
          '\n- 1 teaspoons sesame oil\n'
          '\n- salt and ground white pepper to taste\n'
          '\n- 6 tablespoons all-purpose flour\n'
          '\nSauce:\n'
          '\n- ⅓ cup water\n'
          '\n- ¼ cup coarsely chopped dry roasted peanuts\n'
          '\n- 1 fresh red chile pepper, finely chopped\n'
          '\n- 2 cloves garlic, minced\n'
          '\n- 2 teaspoons white vinegar\n'
          '\n- 1 teaspoon white sugar\n'
          '\n- 1 teaspoon salt\n'
          '\n- oil for frying',
      step: '\nInstructions\n'
          '\n- Slice each tofu square diagonally to make 8 triangles. Make a cut into the base of each tofu triangle and scoop out enough of tofu to create a pocket.\n'
          '\n- Combine scooped-out tofu pieces, prawns, egg, ground chicken, green onion, cornstarch, sesame oil, salt, and pepper in a bowl for the filling. Carefully stuff filling back into the tofu triangles; the filling will bulge out.\n'
          '\n- Meanwhile, make the batter. Mix egg and flour in a bowl. Whisk in enough water to give batter a medium-thin consistency.\n'
          '\n- Combine water, peanuts, red chile pepper, garlic, vinegar, salt, and sugar in a bowl. Stir until salt and sugar have dissolved and set sauce aside.\n'
          '\n-Remove cooked tofu triangles from the steamer.\n'
          '\n-Heat oil in a wok until hot. Dip triangles into the batter and slowly lower into the hot oil. Fry in batches until golden brown and the batter is cooked through, about 5 minutes. Drain on paper towels. Serve hot with the peanut sauce.\n\n'),
  Recipe(
      title: 'Balsamic-Glazed Chicken Wings\n',
      gambar: "lib/img/chiken.jpg",
      rating: "Rating of 4.5/5",
      describe:
      "Put a big stack of napkins on the table because once you start eating these crispy, sticky, sweet glazed chicken wings, you won't want to stop. This can be an appetizer for four or main course for two",
      matrial: 'Ingredient:\n'
          '\n-  cooking spray \n'
          '\n- 3 tablespoons baking powder\n'
          '\n- 1½ teaspoons salt \n'
          '\n- 1½ teaspoons freshly ground black pepper\n'
          '\n- 1 teaspoon paprika\n'
          '\n- 2 pounds chicken wings, split and tips discarded\n'

          '\nGlaze:\n'
          '\n- ⅓  cup water\n'
          '\n- ⅓ cup balsamic vinegar \n'
          '\n- 2 tablespoons soy sauce\n'
          '\n- 2 tablespoons honey\n'
          '\n- 2 tablespoons chili sauce\n'
          '\n- 2 cloves garlic, minced\n'
          '\n- 1 teaspoon water\n'
          '\n- ¼ teaspoon cornstarch\n'

          '\nGarnish:\n'
          '\n1 green onion, thinly sliced \n'
          '\n¼ teaspoon toasted sesame seeds\n',

      step:
      '\nInstructions\n'
          '\n- Preheat an air fryer to 380 degrees F (190 degrees C). Coat the fryer basket with cooking spray.\n'
          '\n- Whisk baking powder, salt, pepper, and paprika together in a small bowl. Place baking powder mixture in a bag, add some of the chicken wings, and shake the bag to coat. Remove wings from the bag, shaking off excess powder, and repeat until all wings are coated with baking powder mixture.\n'
          '\n- Lightly spray the wings with cooking spray, place in the prepared air fryer basket, and cook for 20 minutes, shaking and flipping the wings halfway through. Increase the temperature to 400 degrees F (200 degrees C) and cook until crispy, about 5 minutes more. Depending on the size of your air fryer, you may have to cook the wings in batches.\n'
          '\n- Meanwhile, combine 1/3 cup water, balsamic vinegar, soy sauce, honey, chili sauce, and garlic in a saucepan over medium heat. Bring to a low boil and cook until sauce has reduced, about 15 minutes. Whisk together 1 teaspoon water and cornstarch in a small bowl and pour into the sauce; stir until sauce has thickened.\n'
          '\n- Place crispy wings into a large bowl, drizzle with sauce, and toss until well coated. Garnish with sliced green onion and sesame seeds, and serve immediately.\n'),
  Recipe(
      title: '\nMie Goreng\n',
      gambar: "lib/img/mie.jpg",
      rating: "Rating of 5/5",
      describe:
      "This tasty noodle dish is the same one my mom used to make for me when I was growing up. It's definitely comfort food. You can alter it with adding your favorite meats and veggies. \n",
      matrial: 'Ingredient:\n'
          '\n- 3 (3 ounce) packages ramen noodles \n'
          '\n- 1 pound skinless, boneless chicken breast halves, cut into strips \n'
          '\n- 1 teaspoon olive oil\n'
          '\n- 1 teaspoon garlic salt\n'
          '\n- 1 pinch ground black pepper, or to taste\n'
          '\n- 1 tablespoon vegetable oil \n'
          '\n- ½ cup chopped shallots\n'
          '\n- 5 cloves garlic, chopped\n'
          '\n- 1 cup shredded cabbage\n'
          '\n- 1 cup shredded carrots\n'
          '\n- 1 cup broccoli florets\n'
          '\n- 1 cup sliced fresh mushrooms \n'
          '\n- ¼ cup soy sauce \n'
          '\n- ¼ cup sweet soy sauce \n'
          '\n- 1 teaspoon salt\n'
          '\n- ¼ cup oyster sauce\n'
          '\n- salt and pepper to taste',
      step: '\nInstructions\n'
          '\n- Bring a pan of water to a boil, and cook the ramen until tender, about 3 minutes. Plunge the noodles into cold water to stop the cooking, drain in a colander set in the sink, and drizzle the noodles with 1 tablespoon of vegetable oil. Set aside.\n'
          '\n- Place the chicken strips in a bowl, and toss with olive oil, garlic salt, and black pepper. Heat 1 tablespoon of oil in a wok over high heat, and cook and stir the chicken until it is no longer pink, about 5 minutes. Stir in the shallots and garlic, and cook and stir until they start to turn brown. Add the cabbage, carrots, broccoli, and mushrooms, and cook and stir until the vegetables are tender, about 5 minutes.\n'
          '\n- Stir in the ramen noodles, soy sauce, sweet soy sauce, and oyster sauce, mixing the noodles and sauces into the vegetables and chicken. Bring the mixture to a simmer, sprinkle with salt and pepper, and serve hot.\n'),
];
