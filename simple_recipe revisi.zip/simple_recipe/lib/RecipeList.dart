import 'package:flutter/material.dart';
import 'package:simple_recipe/seaarch.dart';
import 'package:simple_recipe/detailRecipe.dart';
import 'package:simple_recipe/modelRecipe.dart';
import 'package:google_fonts/google_fonts.dart';

class RecipeList extends StatelessWidget {
  const RecipeList({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('simple Recipe'),
          automaticallyImplyLeading: false,
          actions: [
            Center(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Center(),
                  Hero(
                    tag: "appIcon",
                    child: Image.asset(
                      "lib/img/food.png",
                      width: 40,
                      height: 40,
                    ),
                  ),
                  Padding(padding: const EdgeInsets.symmetric(horizontal: 5.0)),
                  Text(
                    "Simple Recipe",
                    style: GoogleFonts.alike(
                      textStyle: Theme.of(context).textTheme.displayMedium,
                      fontSize: 14,
                    ),
                  ),
                  Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 80.0)),
                  IconButton(onPressed: (){
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (context) => searchpage(),
                      ),
                    );
                  }, icon: Icon(Icons.search))

                ],
              ),
            )
          ],
        ),
        body: ListView.builder(
            scrollDirection: Axis.vertical,
            itemCount: recipeList.length,
            itemBuilder: (context, index) {
              Recipe recipe = recipeList[index];
              return Card(
                child: ListTile(
                  title: Text(recipe.title),
                  subtitle: Text(recipe.rating),
                  leading: CircleAvatar(
                    backgroundImage: AssetImage("lib/img/dinner.png"),
                  ),
                  onTap: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => detailRecipe(recipe)));
                  },
                ),
              );
            }));
  }
}
