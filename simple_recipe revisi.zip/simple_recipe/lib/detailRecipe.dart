import 'package:flutter/material.dart';
import 'package:simple_recipe/modelRecipe.dart';
import 'package:google_fonts/google_fonts.dart';

class detailRecipe extends StatelessWidget {
  final Recipe recipe;

  detailRecipe(this.recipe);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: const Color(0xFFFFA500),
          leading: InkWell(
            onTap: () {
              Navigator.pop(context);
            },
          ),
          actions: [
            Center(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Center(),
                  Image.asset(
                    "lib/img/food.png",
                    width: 40,
                    height: 40,
                  ),
                  new Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 5.0)),
                  Text(
                    "Simple Recipe",
                    style: GoogleFonts.alike(
                      textStyle: Theme.of(context).textTheme.displayMedium,
                      fontSize: 14,
                    ),
                  ),
                  new Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 100.0)),
                ],
              ),
            )
          ],
        ),
        body: SingleChildScrollView(
          child: Column(
            children: [
              Image.asset(
                recipe.gambar,
                width: 320,
                height: 280,
              ),
              Row(
                children: [
                  new Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 10.0)),
                  Text(
                    recipe.title,
                    textAlign: TextAlign.left,
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                ],
              ),
              Row(
                children: [
                  new Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 10.0)),
                  Text(recipe.rating),
                ],
              ),
              Container(
                  margin: EdgeInsets.only(left: 20, bottom: 20, top: 10),
                  child: Text(
                    recipe.describe,
                    maxLines: 9,
                  )),
              Row(
                children: [
                  new Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 10.0)),
                  Text(
                    "Recipe",
                    style: TextStyle(fontWeight: FontWeight.bold),
                  )
                ],
              ),
              Container(
                margin: EdgeInsets.all(15),
                padding: EdgeInsets.all(15),
                decoration: BoxDecoration(
                  color: const Color(0xfff3e0b5), //E2D5BDFF
                  borderRadius: BorderRadius.circular(12),
                ),
                alignment: Alignment.topLeft,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Align(
                      alignment: Alignment.topLeft,
                    ),
                    Padding(padding: EdgeInsets.only(bottom: 5, left: 10)),
                    Text(recipe.matrial),
                    Padding(padding: EdgeInsets.only(bottom: 5, left: 10)),
                    Text(recipe.step),
                  ],
                ),
              ),
            ],
          ),
        ));
  }
}
